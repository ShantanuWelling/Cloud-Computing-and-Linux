# CS695 Assignment 2 - Part 2

matrix is a example program to demonstrate running of two VM using KVM API. Tested in Intel processors with the VMX hardware virtualization extensions and AMD processors with AMD-V hardware virtualization extensions.

## How to run

````bash
make
./matrix
````

Performing a ```make clean``` will remove the executable and the object files. You should perform this while updating the code and recompiling.
